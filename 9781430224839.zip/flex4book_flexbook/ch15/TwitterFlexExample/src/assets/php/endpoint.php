<?php
$sURI = strtolower($_SERVER['REQUEST_METHOD']) == 'post' ? $_POST['uri'] : $_GET['uri'];
$ch = curl_init("http://twitter.com/{$sURI}");
if ( strtolower($_SERVER['REQUEST_METHOD']) == 'post' && count($_POST) > 0 )
{
	curl_setopt($ch,CURLOPT_POST,TRUE);

	$aPost = array();
	foreach($_POST as $sIndex => $sValue)
	{
		$aPost[]="{$sIndex}=" . utf8_encode($sValue);
	}
	curl_setopt($ch, CURLOPT_POSTFIELDS,implode("&",$aPost));
}
curl_setopt($ch,CURLOPT_USERPWD,"user:password");
curl_setopt($ch,CURLOPT_RETURNTRANSFER, 1);
echo curl_exec($ch);
curl_close($ch);
?>
